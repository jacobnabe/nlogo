# Summary functions for the class "netout"

setClass("summary.netout")

setMethod("summary", "netout",
	function(object) {
		obj = list()
		obj[["class"]] = class(object)
		obj[["model.name"]] = object@model.name
		obj[["run.name"]] = object@run.name
		obj[["run.time"]] = object@run.time
		obj[["notes"]] = object@notes
		obj[["vars.1"]] = object@vars.1
		obj[["vars.2"]] = object@vars.2
		obj[["data.summary"]] = summary(object@data)
		class(obj) = "summary.netout"
		return(obj)
	}
)

print.summary.netout <- function(x, ...) attributes(x)
setGeneric("print.summary.netout")

setMethod("print", "summary.netout", 
	function(x, ...) {
		cat("An object of class \"", class(x)[[1]], "\"\n", sep="")
		cat("model.name:\t", x$model.name, "\n")
		cat("run.name:  \t", x$run.name, "\n")
		cat("run.time: \t", x$run.time, "\n")
		cat("notes:     \t", x$notes, "\n")
		cat("\nvars.1:\n")
		print(x$vars.1)
		cat("\nvars.2:\n")
		print(x$vars.2)
		cat("\ndata:\n")
		print(x$data.summary)
	}
)

####

# setClass("head.netout")

# setMethod("head", "netout",
	# function(object) {
		# obj = list()
		# obj[["class"]] = class(object)
		# obj[["model.name"]] = object@model.name
		# obj[["run.name"]] = object@run.name
		# obj[["run.time"]] = object@run.time
		# obj[["notes"]] = object@notes
		# obj[["vars.1"]] = object@vars.1
		# obj[["vars.2"]] = object@vars.2
		# obj[["data.head"]] = head(object@data)
		# class(obj) = "head.netout"
		# return(obj)
	# }
# )

# # head.netout <- function(x) attributes(x)
# setGeneric("head.netout")

# setMethod("head", "netout", 
	# function(x) {
		# cat("An object of class \"", class(x)[[1]], "\"\n", sep="")
		# cat("model.name:\t", x@model.name, "\n")
		# cat("run.name:  \t", x@run.name, "\n")
		# cat("run.time: \t", x@run.time, "\n")
		# cat("notes:     \t", x@notes, "\n")
		# cat("\nvars.1:\n")
		# print(x@vars.1)
		# cat("\nvars.2:\n")
		# print(x@vars.2)
		# cat("\ndata:\n")
		# print(head(x@data))
	# }
# )
